# -*- coding: utf-8 -*-
"""
Created on Thu Nov 20 18:58:23 2025

@author: ncortor
"""


import os
import pandas as pd
import numpy as np
import time
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import random
from pathlib import Path
from tqdm import tqdm

__author__ = 'Ing. MSc.  PhD(c) Nicolás Cortés-Torres'
__copyright__ = "Copyright 2024, NCT"
__credits__ = ["Nicolás Cortés-Torres"]
__license__ = "GIMHA"
__version__ = "0.1"
__maintainer__ = "Nicolás Cortés-Torres"
__email__ = 'ncortor@doctor.upv.es, ingcortest@gmail.com'
__status__ = "developing"

#%%######## FUNCIONES

################################################################################
# Funcion apra definir la hora actual
def def_hora():
    return time.strftime("%d-%m-%Y %H:%M:%S", time.localtime())
   
################################################################################
def rmse(obs, sim):
    """ Root mean squared error
    Esta función calcula la raiz cuadrada del error medio cuadratico entre los datos observados y los datos simulados
    :param obs: Arreglo por columnas con los datos observados
    :param sim: Arreglo por columnas con los datos simulados
    :return: Vector con la raiz cuadrada del error medio cuadratico entre los datos observados y los datos simulados
    """
    # n = np.array(map(len, obs.T))
    n = len(obs)
    return np.sqrt(np.nansum(np.power(obs - sim, 2), axis=0) / n)

################################################################################
def rsqr(obs, sim):
    """ Coefficient of determination
    Esta función calcula el coeficiente de determinación entre los datos observados y los datos simulados
    :param obs: Arreglo por columnas con los datos observados
    :param sim: Arreglo por columnas con los datos simulados
    :return: Vector con el coeficiente de determinación entre los datos observados y los datos simulados
    """
    a = obs - np.nanmean(obs, axis=0)
    b = sim - np.nanmean(sim, axis=0)
    return np.power((np.nansum(a * b, axis=0) / np.sqrt(np.nansum(np.power(a, 2), axis=0) * np.nansum(np.power(b, 2), axis=0))), 2)
    
#%%#############################################################################################################
############################### Prediction Tool for excution times on TETIS ####################################
################################################################################################################
tic = time.time()
script_dir = Path.cwd()
print(f"✅ Reading User predictor variables --- {def_hora()} ---")

PV_path = script_dir / "User_predictor_variables.csv"
PV = pd.read_csv(PV_path, encoding="utf-8")

# Read user inputs
speed= float(PV.iloc[0, 1])                                     # Max turbo frequency
area_km2= float(PV.iloc[1, 1])                                  # Basin area in square kilometers
cell_size_m = float(PV.iloc[2, 1])                              # Cell size in meters
ini = pd.to_datetime(PV.iloc[3, 1], format='%d/%m/%Y %H:%M')    # Initial date
fin = pd.to_datetime(PV.iloc[4, 1], format='%d/%m/%Y %H:%M')    # Final date
dt = float(PV.iloc[5, 1])                                         # Delta t in minutes
n_in = float(PV.iloc[6, 1])                                       # Number of input gauges
n_out = float(PV.iloc[7, 1])                                      # Number of output gauges
ram = float(PV.iloc[8, 1])                                        # RAM memory capacity
n_core = float(PV.iloc[9, 1])                                     # Number of cores
n_thr = float(PV.iloc[10, 1])                                     # Number of threads

# Calculate predictor variable with user inputs
cell_area = ((cell_size_m*cell_size_m)/1000000)
cells = area_km2 / cell_area
timesteps = (fin - ini).total_seconds() / (60*dt)

# Vector with Topolco predictor variables
Top_pv = pd.DataFrame([speed, cells, ram, n_core, n_thr], 
                     index = ['Max turbo frequency', 'Basin cells', 'RAM memory', 'Cores', 'Threads']).T

# Vector with HS predictor variables
Sim_pv = pd.DataFrame([speed, cells, timesteps, n_in, n_out],
                      index = ['Max turbo frequency', 'Basin cells', 'Time steps', 'Input gauges', 'Output gauges']).T

# Check for no NAN Columns
Top_no_nan = Top_pv.columns[Top_pv.notna().all(axis=0)].tolist()
Sim_no_nan = Sim_pv.columns[Sim_pv.notna().all(axis=0)].tolist()

# Filter Topolco by no NAN Columns:
Top_pv_user = Top_pv[Top_no_nan]
Sim_pv_user = Sim_pv[Sim_no_nan]

#Read Hiperparameters
Top_HiperP_path = script_dir / "Topolco_Hyperparameter.pickle"
Top_hiperp = pd.read_pickle(Top_HiperP_path)

Sim_HiperP_path = script_dir / "Tetis_Hyperparameter.pickle"
Sim_hiperp = pd.read_pickle(Sim_HiperP_path)


# Search Hiperparameters combination
Top_to_search = ", ".join(Top_no_nan)
Sim_to_search = ", ".join(Sim_no_nan)

# Filter the DataFrame where the column is EXACTLY equal to the searched string
Top_hiper_selec = Top_hiperp[Top_hiperp['Combinacion_Indices'] == Top_to_search]
Sim_hiper_selec = Sim_hiperp[Sim_hiperp['Combinacion_Indices'] == Sim_to_search]

if not Top_hiper_selec.empty:
    print("\n✅ Topolco hiperparameters found!")
else:
    print(f"\n❌ No Topolco hyperparameters were found for the combination of given predictor variables")

if not Sim_hiper_selec.empty:
    print("✅ Hydrological simulation  hiperparameters found!\n")
else:
    print(f"❌ No Hydrological simulation hyperparameters were found for the combination of given predictor variables\n")

# Allocate hiperparameters for RF model 
top_estimator = int(Top_hiper_selec.iloc[0, 8])  
top_depth = int(Top_hiper_selec.iloc[0, 9]) 
top_split = int(Top_hiper_selec.iloc[0, 10]) 
top_leaf =  int(Top_hiper_selec.iloc[0, 11]) 
sim_estimator = int(Sim_hiper_selec.iloc[0, 8])  
sim_depth = int(Sim_hiper_selec.iloc[0, 9]) 
sim_split = int(Sim_hiper_selec.iloc[0, 10]) 
sim_leaf =  int(Sim_hiper_selec.iloc[0, 11]) 

# Read data for RF model
data_sim_path = script_dir / "Database_times_tetis.pickle"
data_sim = pd.read_pickle(data_sim_path)

data_top_path = script_dir / "Database_times_topolco.pickle"
data_top = pd.read_pickle(data_top_path)

# Crea un nuevo DataFrame solo con estas columnas
df_sim_X = data_sim[Sim_no_nan].values
df_top_X = data_top[Top_no_nan].values

df_sim_Y = data_sim.iloc[:, 7].values
df_top_Y = data_top.iloc[:, 6].values


#%%########### ---  Aplicación de la predicción---

#Aplicación Random Forest
n_iter=100
Top_times = []
Sim_times = []
# for i in range(0,n_iter):
    
for i in tqdm(range(0,n_iter),
              desc="Processing Random Forest models",
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}"):
    # TOPOCO RF model
    Top_X_train, Top_X_test, Top_Y_train, Top_Y_test = train_test_split(
    df_top_X, 
    df_top_Y.ravel(), 
    test_size= random.uniform(0.20,0.30),    # 20% de los datos se usarán para la prueba
    random_state= random.randint(0, 4294967295)  # Semilla para asegurar que el split sea reproducible
    )
    
    Top_rf = RandomForestRegressor(n_estimators=top_estimator, 
                               max_depth=top_depth, 
                               min_samples_split=top_split, 
                               min_samples_leaf=top_leaf)# Definition of the algorithm

    Top_rf.fit(Top_X_train, Top_Y_train) # Algorithm training  
    Top_Y_sim = Top_rf.predict(Top_X_test) # Calculate simulate Y for RF 

    top_index_rmse = rmse(Top_Y_test, Top_Y_sim) # Metric rmse
    top_index_rsqr = rsqr(Top_Y_test, Top_Y_sim) # Metric rsqr

    Top_time_user = Top_rf.predict(Top_pv_user.values) # Calculate simulate Y 
    
    Top_times.append({
        'Time': Top_time_user[0],
        'rmse': top_index_rmse,
        'rsqr': top_index_rsqr
        })
        
    # Hydrological Simulation RF model
    Sim_X_train, Sim_X_test, Sim_Y_train, Sim_Y_test = train_test_split(
    df_sim_X, 
    df_sim_Y.ravel(), 
    test_size= random.uniform(0.20,0.30),    # 20% de los datos se usarán para la prueba
    random_state= random.randint(0, 4294967295)  # Semilla para asegurar que el split sea reproducible
    )
    
    Sim_rf = RandomForestRegressor(n_estimators=sim_estimator, 
                               max_depth=sim_depth, 
                               min_samples_split=sim_split, 
                               min_samples_leaf=sim_leaf)# Definition of the algorithm

    Sim_rf.fit(Sim_X_train, Sim_Y_train) # Algorithm training  
    Sim_Y_sim = Sim_rf.predict(Sim_X_test) # Calculate simulate Y for RF 

    sim_index_rmse = rmse(Sim_Y_test, Sim_Y_sim) # Metric rmse
    sim_index_rsqr = rsqr(Sim_Y_test, Sim_Y_sim) # Metric rsqr

    Sim_time_user = Sim_rf.predict(Sim_pv_user.values) # Calculate simulate Y 
    
    Sim_times.append({
        'Time': Sim_time_user[0],
        'rmse': sim_index_rmse,
        'rsqr': sim_index_rsqr
        })
    pass
        
df_Top_times= pd.DataFrame(Top_times)
df_Sim_times= pd.DataFrame(Sim_times)

top_y_sim_mean = df_Top_times["Time"].mean()
top_y_sim_max = df_Top_times["Time"].max()
top_y_sim_min = df_Top_times["Time"].min()
top_mean_rmse = df_Top_times["rmse"].mean()
top_mean_rsqr = df_Top_times["rsqr"].mean()

sim_y_sim_mean = df_Sim_times["Time"].mean()
sim_y_sim_max = df_Sim_times["Time"].max()
sim_y_sim_min = df_Sim_times["Time"].min()
sim_mean_rmse = df_Sim_times["rmse"].mean()
sim_mean_rsqr = df_Sim_times["rsqr"].mean()

prediction = f"""
=====================================================
||     RUNTIME PREDICTIONS FOR TETIS V9.1        ||
=====================================================
+---------------------------------------------------+
|                TOPOLCO PREDICTION                 |
+---------------------------------------------------+
|                                                   |
| PREDICTOR VARIABLES (min)                         |
|                                                   |
| Max turbo frequency: {speed} GHz
| Basin cells: {int(cells)}
| RAM memory: {ram} Gb
| Cores: {n_core}
| Threads: {n_thr}
+---------------------------------------------------+
|                                                   |
| EXPECTED TIME (min)                               |
|                                                   |
| Expected mean time: {top_y_sim_mean:.3f} min
| Estimated time range: {top_y_sim_min:.3f} min  to {top_y_sim_max:.3f} min
+---------------------------------------------------+
|                                                   |
| MODEL VALIDATION ({n_iter} MC simulations)
|                                                   |
| Average RMSE: {top_mean_rmse:.3f}
| Average R²:   {top_mean_rsqr:.3f}
+---------------------------------------------------+

=====================================================

+---------------------------------------------------+
|        HYDROLOGICAL SIMULATION PREDICTION         |
+---------------------------------------------------+
|                                                   |
| PREDICTOR VARIABLES (min)                         |
|                                                   |
| Max turbo frequency: {speed} GHz
| Basin cells: {int(cells)}
| Time steps: {int(timesteps)}
| Input gauges: {n_in}
| Output gauges: {n_out}
+---------------------------------------------------+
|                                                   |
| EXPECTED TIME (min)                               |
|                                                   |
| Expected mean time: {sim_y_sim_mean:.3f} min
| Estimated time range: {sim_y_sim_min:.3f} min  to {sim_y_sim_max:.3f} min
+---------------------------------------------------+
|                                                   |
| MODEL VALIDATION ({n_iter} MC simulations)
|                                                   |
| Average RMSE: {sim_mean_rmse:.3f}
| Average R²:   {sim_mean_rsqr:.3f}
+---------------------------------------------------+
"""

print(prediction)
prediction_file = script_dir / "Prediction_results.txt"     
with open(prediction_file, 'w', encoding='utf-8') as archivo:
    archivo.write(prediction)
    


#%%#######################################################################################################################
#################                             FINAL CODIGO                       #########################################
##########################################################################################################################

run_time = (time.time() - tic)
hours_ = run_time // 3600.0
minutes_ = round((run_time / 3600.0 - hours_) * 60.0, 1)
text_ = f'Execution total time was {hours_} hours and {minutes_} minutes'
len_text = len(text_)
len_print = len_text + 2 * 10
len_blank = (len_print - 2)
print(len_print * '#')
print('#' + len_blank * ' ' + '#')
print('#' + 9 * ' ' + text_ + 9 * ' ' + '#')
print('#' + len_blank * ' ' + '#')
print(len_print * '#')

input("\n--- Presiona Enter para cerrar la ventana ---")